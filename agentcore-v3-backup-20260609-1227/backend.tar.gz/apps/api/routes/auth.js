const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { z } = require('zod');
const { prisma } = require('../prisma-client');
const config = require('../config');
const { authenticate } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimit');
const { safeError } = require('../utils/errors');

const router = express.Router();

router.post('/register', authLimiter, async (req, res) => {
  try {
    const schema = z.object({
      name: z.string().min(2).max(255),
      email: z.string().email().max(255),
      password: z.string().min(6),
      workspaceName: z.string().max(100).optional()
    });
    const data = schema.parse(req.body);
    const email = data.email.toLowerCase().trim();

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) {
      // perform dummy hash to prevent timing attacks
      await bcrypt.hash(data.password, 10);
      return res.status(400).json({ error: 'Email already registered' });
    }

    const hashedPassword = await bcrypt.hash(data.password, 10);

    const { workspace, user } = await prisma.$transaction(async (tx) => {
      const workspace = await tx.workspace.create({
        data: {
          name: data.workspaceName || data.name + "'s Workspace",
          settings: {}
        }
      });
      const user = await tx.user.create({
        data: {
          name: data.name,
          email,
          password: hashedPassword,
          workspaceId: workspace.id,
          role: 'OWNER'
        }
      });
      return { workspace, user };
    });

    const token = jwt.sign({ userId: user.id, workspaceId: workspace.id, role: user.role, tokenVersion: user.tokenVersion }, config.JWT_SECRET, { expiresIn: config.JWT_EXPIRES_IN || '7d' });
    res.json({
      accessToken: token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      workspaceId: workspace.id
    });
  } catch (err) {
    console.error('Register error:', err);
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: err.flatten() });
    }
    safeError(res, err, 500, 'Registration failed');
  }
});

router.post('/login', authLimiter, async (req, res) => {
  try {
    const { email: rawEmail, password } = z.object({ email: z.string().email(), password: z.string() }).parse(req.body);
    const email = rawEmail.toLowerCase().trim();
    const user = await prisma.user.findUnique({ where: { email } });
    const dummyHash = '$2a$10$dummyhashdummyhashdummyhashdummyhashdu';
    const hashToCompare = user?.password || dummyHash;
    const valid = await bcrypt.compare(password, hashToCompare);
    if (!user || !valid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const workspace = await prisma.workspace.findUnique({ where: { id: user.workspaceId } });
    const token = jwt.sign({ userId: user.id, workspaceId: user.workspaceId, role: user.role, tokenVersion: user.tokenVersion }, config.JWT_SECRET, { expiresIn: config.JWT_EXPIRES_IN || '7d' });
    res.json({
      accessToken: token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      workspaceId: user.workspaceId
    });
  } catch (err) {
    console.error('Login error:', err);
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: err.flatten() });
    }
    safeError(res, err, 500, 'Login failed');
  }
});

router.post('/refresh', authenticate, async (req, res) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user.userId } });
    if (!user) return res.status(404).json({ error: 'User not found' });

    const updated = await prisma.user.update({
      where: { id: user.id },
      data: { tokenVersion: { increment: 1 } }
    });

    const token = jwt.sign(
      { userId: user.id, workspaceId: user.workspaceId, role: user.role, tokenVersion: updated.tokenVersion },
      config.JWT_SECRET,
      { expiresIn: config.JWT_EXPIRES_IN || '7d' }
    );

    res.json({
      accessToken: token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      workspaceId: user.workspaceId
    });
  } catch (err) {
    console.error('Refresh error:', err);
    safeError(res, err);
  }
});

router.post('/logout', authenticate, async (req, res) => {
  try {
    await prisma.user.update({
      where: { id: req.user.userId },
      data: { tokenVersion: { increment: 1 } }
    });
    res.json({ success: true });
  } catch (err) {
    safeError(res, err);
  }
});

router.get('/me', authenticate, async (req, res) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user.userId }, include: { workspace: { select: { id: true, name: true, settings: true } } } });
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ id: user.id, name: user.name, email: user.email, role: user.role, workspace: user.workspace });
  } catch (err) {
    safeError(res, err);
  }
});

router.patch('/me', authenticate, async (req, res) => {
  try {
    const schema = z.object({
      name: z.string().min(2).max(255).optional(),
      email: z.string().email().max(255).optional(),
    });
    const data = schema.parse(req.body);
    const updateData = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.email !== undefined) {
      const newEmail = data.email.toLowerCase().trim();
      const existing = await prisma.user.findUnique({ where: { email: newEmail } });
      if (existing && existing.id !== req.user.userId) {
        return res.status(400).json({ error: 'Email already registered' });
      }
      updateData.email = newEmail;
    }
    const user = await prisma.user.update({
      where: { id: req.user.userId },
      data: updateData
    });
    res.json({ id: user.id, name: user.name, email: user.email, role: user.role });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: err.flatten() });
    }
    safeError(res, err, 500, 'Failed to update profile');
  }
});

router.post('/change-password', authenticate, async (req, res) => {
  try {
    const schema = z.object({
      oldPassword: z.string().min(1),
      newPassword: z.string().min(6),
    });
    const data = schema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { id: req.user.userId } });
    if (!user || !user.password) {
      return res.status(400).json({ error: 'User not found' });
    }
    const valid = await bcrypt.compare(data.oldPassword, user.password);
    if (!valid) {
      return res.status(400).json({ error: 'Invalid old password' });
    }
    const hashedPassword = await bcrypt.hash(data.newPassword, 10);
    await prisma.user.update({
      where: { id: user.id },
      data: { password: hashedPassword, tokenVersion: { increment: 1 } }
    });
    res.json({ success: true });
  } catch (err) {
    console.error('Change password error:', err);
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: err.flatten() });
    }
    safeError(res, err, 500, 'Failed to change password');
  }
});

module.exports = router;
