const { prisma } = require('../prisma-client');
const config = require('../config');

// Get agent credits breakdown
async function getAgentCredits(agentId, workspaceId) {
  if (!agentId) return { total: 0, used: 0, remaining: 0, freeCredits: 0 };

  const agent = await prisma.agent.findUnique({ where: { id: agentId } });
  if (!agent || agent.workspaceId !== workspaceId) return { total: 0, used: 0, remaining: 0, freeCredits: 0 };

  const freeCredits = config.AGENT_FREE_CREDITS;
  const used = await prisma.creditConsumptionLog.aggregate({
    where: { agentId },
    _sum: { amount: true }
  });
  const usedAmount = (used._sum?.amount) || 0;

  return {
    total: freeCredits,
    used: usedAmount,
    remaining: Math.max(0, freeCredits - usedAmount),
    freeCredits
  };
}

// Check and deduct credits for AI usage
async function checkAndDeductCredits(workspaceId, agentId, estimatedCost) {
  if (!agentId) return true;

  const agent = await prisma.agent.findFirst({
    where: { id: agentId, workspaceId }
  });
  if (!agent) return false;

  const freeCredits = config.AGENT_FREE_CREDITS;
  const usedAgg = await prisma.creditConsumptionLog.aggregate({
    where: { agentId },
    _sum: { amount: true }
  });
  const used = (usedAgg._sum?.amount) || 0;
  const remainingFree = Math.max(0, freeCredits - used);

  if (remainingFree >= estimatedCost) {
    await prisma.creditConsumptionLog.create({
      data: {
        workspaceId,
        agentId,
        amount: estimatedCost,
        reason: 'ai_request',
        model: agent.model
      }
    });
    return true;
  }

  // Check workspace top-up balance
  const topUpAgg = await prisma.billingTransaction.aggregate({
    where: { workspaceId, type: 'topup', status: 'completed' },
    _sum: { amount: true }
  });
  const topUpBalance = (topUpAgg._sum?.amount) || 0;

  const totalUsedAgg = await prisma.creditConsumptionLog.aggregate({
    where: { workspaceId },
    _sum: { amount: true }
  });
  const totalUsed = (totalUsedAgg._sum?.amount) || 0;
  const totalRemaining = Math.max(0, topUpBalance - Math.max(0, totalUsed - freeCredits));

  if (totalRemaining >= estimatedCost) {
    await prisma.creditConsumptionLog.create({
      data: {
        workspaceId,
        agentId,
        amount: estimatedCost,
        reason: 'ai_request',
        model: agent.model
      }
    });
    return true;
  }

  return false;
}

module.exports = { getAgentCredits, checkAndDeductCredits };
