'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getUserRole } from '@/utils/auth';
import DataTable from '@/components/admin/DataTable';
import AlertBadge from '@/components/admin/AlertBadge';
import { useAdminStore } from '@/store/adminStore';
import { Bell, CheckCircle } from 'lucide-react';

export default function AdminAlertsPage() {
  const router = useRouter();
  const [checked, setChecked] = useState(false);
  const [typeFilter, setTypeFilter] = useState('');
  const [resolvedFilter, setResolvedFilter] = useState('false');
  const { alerts, isLoading, error, fetchAlerts, resolveAlert } = useAdminStore();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/login');
      return;
    }
    const role = getUserRole();
    const allowed = ['SUPERADMIN', 'ADMIN', 'SUPPORT'];
    if (!role || !allowed.includes(role)) {
      router.push('/agents');
      return;
    }
    setChecked(true);
  }, [router]);

  useEffect(() => {
    if (!checked) return;
    fetchAlerts({
      type: typeFilter || undefined,
      resolved: resolvedFilter === 'all' ? undefined : resolvedFilter === 'true',
    });
  }, [checked, typeFilter, resolvedFilter, fetchAlerts]);

  if (!checked) return null;

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <Bell size={20} className="text-brand" />
        <h1 className="text-xl font-semibold text-text tracking-heading">Alerts</h1>
      </div>

      {error && (
        <div className="px-4 py-3 rounded-card bg-danger-soft border border-danger/10 text-sm text-danger">
          {error}
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs text-text-muted">Type:</span>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-1.5 text-sm bg-surface border border-border rounded-button text-text outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-1"
          >
            <option value="">All types</option>
            <option value="error">Error</option>
            <option value="warning">Warning</option>
            <option value="info">Info</option>
            <option value="success">Success</option>
          </select>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-text-muted">Status:</span>
          <select
            value={resolvedFilter}
            onChange={(e) => setResolvedFilter(e.target.value)}
            className="px-3 py-1.5 text-sm bg-surface border border-border rounded-button text-text outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-1"
          >
            <option value="false">Unresolved</option>
            <option value="true">Resolved</option>
            <option value="all">All</option>
          </select>
        </div>
      </div>

      <DataTable
        columns={[
          {
            key: 'type',
            header: 'Type',
            render: (row) => <AlertBadge type={String(row.type) as 'error' | 'warning' | 'info' | 'success'} />,
          },
          { key: 'title', header: 'Title', sortable: true },
          { key: 'message', header: 'Message', render: (row) => <span className="text-xs text-text-muted max-w-xs truncate">{String(row.message ?? '')}</span> },
          {
            key: 'resolved',
            header: 'Status',
            render: (row) => (
              Boolean(row.resolved) ? (
                <span className="inline-flex items-center gap-1 text-xs font-medium text-success">
                  <CheckCircle size={12} />
                  Resolved
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-medium text-warning">
                  <Bell size={12} />
                  Open
                </span>
              )
            ),
          },
          {
            key: 'createdAt',
            header: 'Created',
            sortable: true,
            render: (row) => (
              <span className="text-xs text-text-muted">
                {new Date(row.createdAt as string).toLocaleString('ru-RU')}
              </span>
            ),
          },
          {
            key: 'actions',
            header: '',
            render: (row) => (
              !Boolean(row.resolved) ? (
                <button
                  type="button"
                  onClick={async () => {
                    await resolveAlert(row.id as string);
                  }}
                  className="px-3 py-1.5 text-xs font-medium bg-brand text-white rounded-button hover:bg-brand-hover transition-colors"
                >
                  Resolve
                </button>
              ) : (
                <span className="text-xs text-text-muted">—</span>
              )
            ),
          },
        ]}
        data={alerts}
        loading={isLoading}
        pageSize={15}
        emptyMessage="No alerts found"
      />
    </div>
  );
}
