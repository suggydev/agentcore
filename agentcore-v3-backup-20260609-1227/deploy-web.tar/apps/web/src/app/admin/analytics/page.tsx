'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getUserRole } from '@/utils/auth';
import ChartCard from '@/components/admin/ChartCard';
import DateRangePicker, { type DateRange } from '@/components/admin/DateRangePicker';
import { useAdminStore } from '@/store/adminStore';
import { BarChart3 } from 'lucide-react';

function SvgBarChart({ data, label }: { data: { label: string; value: number }[]; label: string }) {
  if (!data.length) return <div className="text-sm text-text-muted">No data</div>;
  const max = Math.max(...data.map((d) => d.value), 1);
  const height = 160;
  const barWidth = Math.max(4, (data.length > 0 ? 100 / data.length : 0));
  return (
    <div className="space-y-2">
      <div className="flex items-end gap-1 h-[160px]">
        {data.map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <div
              className="w-full bg-brand/70 rounded-sm hover:bg-brand transition-colors"
              style={{ height: `${(d.value / max) * 100}%`, minHeight: d.value > 0 ? 4 : 0 }}
              title={`${d.label}: ${d.value}`}
            />
          </div>
        ))}
      </div>
      <div className="flex justify-between text-[10px] text-text-muted">
        <span>{data[0]?.label}</span>
        <span>{label}</span>
        <span>{data[data.length - 1]?.label}</span>
      </div>
    </div>
  );
}

function ModelTable({ data }: { data: { model: string; tokensIn: number; tokensOut: number; cost: number; avgLatency: number; count: number }[] }) {
  if (!data.length) return <div className="text-sm text-text-muted">No model usage data</div>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="border-b border-border">
            <th className="px-3 py-2 text-left text-text-muted font-semibold">Model</th>
            <th className="px-3 py-2 text-right text-text-muted font-semibold">Requests</th>
            <th className="px-3 py-2 text-right text-text-muted font-semibold">Tokens In</th>
            <th className="px-3 py-2 text-right text-text-muted font-semibold">Tokens Out</th>
            <th className="px-3 py-2 text-right text-text-muted font-semibold">Cost</th>
            <th className="px-3 py-2 text-right text-text-muted font-semibold">Avg Latency</th>
          </tr>
        </thead>
        <tbody>
          {data.map((m, i) => (
            <tr key={i} className="border-b border-border last:border-b-0 hover:bg-surface-2/50 transition-colors">
              <td className="px-3 py-2 text-text-secondary font-medium">{m.model}</td>
              <td className="px-3 py-2 text-right tabular-nums">{m.count.toLocaleString()}</td>
              <td className="px-3 py-2 text-right tabular-nums">{m.tokensIn.toLocaleString()}</td>
              <td className="px-3 py-2 text-right tabular-nums">{m.tokensOut.toLocaleString()}</td>
              <td className="px-3 py-2 text-right tabular-nums">₽{m.cost.toFixed(2).replace('.', ',')}</td>
              <td className="px-3 py-2 text-right tabular-nums">{m.avgLatency}ms</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function AdminAnalyticsPage() {
  const router = useRouter();
  const [checked, setChecked] = useState(false);
  const [dateRange, setDateRange] = useState<DateRange>({
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
    end: new Date().toISOString().slice(0, 10),
    label: 'Last 30 days',
    days: 30,
  });
  const {
    analyticsSignups,
    analyticsActivity,
    analyticsRevenue,
    analyticsModels,
    isLoading,
    error,
    fetchAnalytics,
    setDateRange: storeSetDateRange,
  } = useAdminStore();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/login');
      return;
    }
    const role = getUserRole();
    const allowed = ['SUPERADMIN', 'ADMIN', 'SUPPORT', 'ANALYST'];
    if (!role || !allowed.includes(role)) {
      router.push('/agents');
      return;
    }
    setChecked(true);
  }, [router]);

  useEffect(() => {
    if (!checked) return;
    storeSetDateRange({ start: dateRange.start, end: dateRange.end, days: dateRange.days });
    fetchAnalytics(dateRange.days);
  }, [checked, dateRange, fetchAnalytics, storeSetDateRange]);

  if (!checked) return null;

  const signups = analyticsSignups.map((s) => ({ label: s.date.slice(5), value: s.count ?? 0 }));
  const revenue = analyticsRevenue.map((r) => ({ label: r.date.slice(5), value: r.amount ?? 0 }));
  const dau = analyticsActivity.map((a) => ({ label: a.date.slice(5), value: a.dau ?? 0 }));
  const sessions = analyticsActivity.map((a) => ({ label: a.date.slice(5), value: a.sessions ?? 0 }));

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <BarChart3 size={20} className="text-brand" />
          <h1 className="text-xl font-semibold text-text tracking-heading">Analytics</h1>
        </div>
        <DateRangePicker value={dateRange} onChange={setDateRange} />
      </div>

      {error && (
        <div className="px-4 py-3 rounded-card bg-danger-soft border border-danger/10 text-sm text-danger">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ChartCard title="Signups" subtitle={dateRange.label} delay={0}>
          <SvgBarChart data={signups} label="New users" />
        </ChartCard>
        <ChartCard title="Revenue" subtitle={dateRange.label} delay={0.05}>
          <SvgBarChart data={revenue} label="Revenue" />
        </ChartCard>
        <ChartCard title="Daily Active Users" subtitle={dateRange.label} delay={0.1}>
          <SvgBarChart data={dau} label="DAU" />
        </ChartCard>
        <ChartCard title="Sessions" subtitle={dateRange.label} delay={0.15}>
          <SvgBarChart data={sessions} label="Sessions" />
        </ChartCard>
      </div>

      <ChartCard title="Model Usage" subtitle={dateRange.label} delay={0.2} className="">
        <ModelTable data={analyticsModels} />
      </ChartCard>
    </div>
  );
}
