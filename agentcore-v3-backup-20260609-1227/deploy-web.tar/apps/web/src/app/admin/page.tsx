'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getUserRole } from '@/utils/auth';
import KpiCard from '@/components/admin/KpiCard';
import ChartCard from '@/components/admin/ChartCard';
import ActivityFeed from '@/components/admin/ActivityFeed';
import { useAdminStore } from '@/store/adminStore';
import {
  Users,
  Building2,
  MessageSquare,
  Bot,
  DollarSign,
  AlertTriangle,
  Activity,
  TrendingUp,
  Server,
} from 'lucide-react';

function formatCurrency(n: number) {
  return `₽${n.toLocaleString('ru-RU', { maximumFractionDigits: 0 })}`;
}

function SimpleBarChart({ data, label }: { data: { date: string; value: number }[]; label: string }) {
  if (!data.length) return <div className="text-sm text-text-muted">No data</div>;
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div className="space-y-2">
      <div className="flex items-end gap-1 h-[120px]">
        {data.slice(-14).map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <div
              className="w-full bg-brand/70 rounded-sm hover:bg-brand transition-colors"
              style={{ height: `${(d.value / max) * 100}%`, minHeight: d.value > 0 ? 4 : 0 }}
              title={`${d.date}: ${d.value}`}
            />
          </div>
        ))}
      </div>
      <div className="flex justify-between text-[10px] text-text-muted">
        <span>{data[0]?.date}</span>
        <span>{label}</span>
        <span>{data[data.length - 1]?.date}</span>
      </div>
    </div>
  );
}

export default function AdminDashboardPage() {
  const router = useRouter();
  const [checked, setChecked] = useState(false);
  const {
    dashboardKPIs,
    analyticsSignups,
    analyticsRevenue,
    isLoading,
    error,
    fetchDashboard,
    fetchAnalytics,
  } = useAdminStore();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/login');
      return;
    }
    const role = getUserRole();
    const allowed = ['SUPERADMIN', 'ADMIN', 'SUPPORT', 'ANALYST'];
    if (!role || !allowed.includes(role)) {
      router.push('/agents');
      return;
    }
    setChecked(true);
  }, [router]);

  useEffect(() => {
    if (!checked) return;
    fetchDashboard();
    fetchAnalytics(14);
    const interval = setInterval(() => {
      fetchDashboard();
    }, 30000);
    return () => clearInterval(interval);
  }, [checked, fetchDashboard, fetchAnalytics]);

  if (!checked) return null;

  const kpi = dashboardKPIs;

  const signupData = analyticsSignups.map((s) => ({ date: s.date, value: s.count ?? 0 }));
  const revenueData = analyticsRevenue.map((r) => ({ date: r.date, value: r.amount ?? 0 }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-text tracking-heading">Dashboard</h1>
        <div className="flex items-center gap-2 text-xs text-text-muted">
          <Activity size={14} className="text-success" />
          <span>Live</span>
        </div>
      </div>

      {error && (
        <div className="px-4 py-3 rounded-card bg-danger-soft border border-danger/10 text-sm text-danger">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard
          title="Total Users"
          value={kpi?.totalUsers ?? 0}
          trend={12}
          trendLabel="vs last month"
          icon={Users}
          color="brand"
          delay={0}
        />
        <KpiCard
          title="Workspaces"
          value={kpi?.totalWorkspaces ?? 0}
          icon={Building2}
          color="success"
          delay={0.05}
        />
        <KpiCard
          title="Total Messages"
          value={kpi?.totalMessages?.toLocaleString() ?? 0}
          icon={MessageSquare}
          color="warning"
          delay={0.1}
        />
        <KpiCard
          title="Revenue"
          value={formatCurrency(kpi?.totalRevenue ?? 0)}
          trend={8}
          trendLabel="vs last month"
          icon={DollarSign}
          color="success"
          delay={0.15}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
          <ChartCard title="Signups" subtitle="Last 14 days" delay={0.2}>
            <SimpleBarChart data={signupData} label="Users" />
          </ChartCard>
          <ChartCard title="Revenue" subtitle="Last 14 days" delay={0.25}>
            <SimpleBarChart data={revenueData} label="Revenue" />
          </ChartCard>
        </div>

        <ChartCard title="Live Activity" subtitle="Real-time events" delay={0.3}>
          <ActivityFeed />
        </ChartCard>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="Agents"
          value={kpi?.totalAgents ?? 0}
          icon={Bot}
          color="brand"
          delay={0.35}
        />
        <KpiCard
          title="Active Today"
          value={kpi?.activeUsersToday ?? 0}
          icon={TrendingUp}
          color="success"
          delay={0.4}
        />
        <KpiCard
          title="Alerts"
          value={kpi?.unresolvedAlerts ?? 0}
          icon={AlertTriangle}
          color={kpi?.unresolvedAlerts ? 'danger' : 'success'}
          delay={0.45}
        />
        <KpiCard
          title="System Uptime"
          value={kpi?.systemHealth ? `${Math.floor(kpi.systemHealth.uptime / 3600)}h` : '—'}
          icon={Server}
          color="brand"
          delay={0.5}
        />
      </div>
    </div>
  );
}
