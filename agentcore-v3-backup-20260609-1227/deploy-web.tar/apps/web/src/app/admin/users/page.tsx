'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getUserRole } from '@/utils/auth';
import DataTable from '@/components/admin/DataTable';
import AlertBadge from '@/components/admin/AlertBadge';
import { useAdminStore } from '@/store/adminStore';
import { Search, Users } from 'lucide-react';

export default function AdminUsersPage() {
  const router = useRouter();
  const [checked, setChecked] = useState(false);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const { users, isLoading, error, fetchUsers } = useAdminStore();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/login');
      return;
    }
    const role = getUserRole();
    const allowed = ['SUPERADMIN', 'ADMIN', 'SUPPORT'];
    if (!role || !allowed.includes(role)) {
      router.push('/agents');
      return;
    }
    setChecked(true);
  }, [router]);

  useEffect(() => {
    if (!checked) return;
    fetchUsers({ search: search || undefined, role: roleFilter || undefined });
  }, [checked, search, roleFilter, fetchUsers]);

  if (!checked) return null;

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <Users size={20} className="text-brand" />
        <h1 className="text-xl font-semibold text-text tracking-heading">Users</h1>
      </div>

      {error && (
        <div className="px-4 py-3 rounded-card bg-danger-soft border border-danger/10 text-sm text-danger">
          {error}
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or email..."
            className="w-full pl-9 pr-4 py-2 text-sm bg-surface border border-border rounded-button text-text placeholder:text-text-muted outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-1"
          />
        </div>
        <select
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value)}
          className="px-3 py-2 text-sm bg-surface border border-border rounded-button text-text outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-1"
        >
          <option value="">All roles</option>
          <option value="OWNER">OWNER</option>
          <option value="ADMIN">ADMIN</option>
          <option value="SUPPORT">SUPPORT</option>
          <option value="ANALYST">ANALYST</option>
        </select>
      </div>

      <DataTable
        columns={[
          { key: 'name', header: 'Name', sortable: true },
          { key: 'email', header: 'Email', sortable: true },
          { key: 'role', header: 'Role', sortable: true, render: (row) => <span className="text-xs font-medium">{row.role}</span> },
          {
            key: 'workspace',
            header: 'Workspace',
            render: (row) => <span className="text-xs text-text-muted">{(row.workspace as { name?: string } | undefined)?.name || '—'}</span>,
          },
          {
            key: 'plan',
            header: 'Plan',
            render: (row) => <span className="text-xs text-text-muted">{(row.workspace as { plan?: string } | undefined)?.plan || '—'}</span>,
          },
          {
            key: 'createdAt',
            header: 'Joined',
            sortable: true,
            render: (row) => (
              <span className="text-xs text-text-muted">
                {new Date(row.createdAt as string).toLocaleDateString('ru-RU')}
              </span>
            ),
          },
        ]}
        data={users}
        loading={isLoading}
        pageSize={10}
        emptyMessage="No users found"
      />
    </div>
  );
}
