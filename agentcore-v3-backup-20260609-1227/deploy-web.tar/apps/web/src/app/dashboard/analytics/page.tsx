'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function DashboardAnalyticsRedirect() {
  const router = useRouter();
  useEffect(() => {
    router.push('/agents');
  }, [router]);
  return null;
}
