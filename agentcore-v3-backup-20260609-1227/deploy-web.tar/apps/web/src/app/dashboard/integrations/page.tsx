'use client';

import { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'next/navigation';
import { motion } from 'framer-motion';
import ChannelGrid from '@/components/integrations/ChannelGrid';
import type { Provider, AgentIntegration } from '@/components/integrations/types';

function getToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('token');
}

function getApiBase(): string {
  return process.env.NEXT_PUBLIC_API_URL || '';
}

export default function IntegrationsPage() {
  const searchParams = useSearchParams();
  const [providers, setProviders] = useState<Provider[]>([]);
  const [integrations, setIntegrations] = useState<AgentIntegration[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const agentId =
    searchParams.get('agentId') ||
    (typeof window !== 'undefined' ? localStorage.getItem('currentAgentId') : null) ||
    '';

  const fetchProviders = useCallback(async () => {
    const token = getToken();
    if (!token) return;
    try {
      const res = await fetch(`${getApiBase()}/api/integrations/providers`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Не удалось загрузить список провайдеров');
      const data = (await res.json()) as { providers?: Provider[] } | Provider[];
      const list = Array.isArray(data) ? data : data.providers || [];
      setProviders(list);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки провайдеров');
    }
  }, []);

  const fetchIntegrations = useCallback(async () => {
    if (!agentId) return;
    const token = getToken();
    if (!token) return;
    try {
      const res = await fetch(
        `${getApiBase()}/api/integrations?agentId=${encodeURIComponent(agentId)}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (!res.ok) throw new Error('Не удалось загрузить интеграции агента');
      const data = (await res.json()) as { integrations?: AgentIntegration[] } | AgentIntegration[];
      const list = Array.isArray(data) ? data : data.integrations || [];
      setIntegrations(list);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки интеграций');
    } finally {
      setLoading(false);
    }
  }, [agentId]);

  useEffect(() => {
    fetchProviders();
  }, [fetchProviders]);

  useEffect(() => {
    fetchIntegrations();
  }, [fetchIntegrations]);

  const handleConnect = useCallback(
    async (providerId: string, mode: string | null, config: Record<string, unknown>) => {
      const token = getToken();
      if (!token || !agentId) throw new Error('Не авторизован или не выбран агент');
      const res = await fetch(`${getApiBase()}/api/integrations`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ agentId, providerId, mode, config }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || 'Ошибка подключения');
      }
      const created = (await res.json()) as AgentIntegration;
      setIntegrations((prev) => [...prev, created]);
    },
    [agentId]
  );

  const handleDisconnect = useCallback(async (integrationId: string) => {
    const token = getToken();
    if (!token) throw new Error('Не авторизован');
    const res = await fetch(`${getApiBase()}/api/integrations/${integrationId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Ошибка отключения');
    }
    setIntegrations((prev) => prev.filter((i) => i.id !== integrationId));
  }, []);

  const handleUpdate = useCallback(
    async (integrationId: string, config: Record<string, unknown>) => {
      const token = getToken();
      if (!token) throw new Error('Не авторизован');
      const res = await fetch(`${getApiBase()}/api/integrations/${integrationId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ config }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || 'Ошибка обновления');
      }
      const updated = (await res.json()) as AgentIntegration;
      setIntegrations((prev) => prev.map((i) => (i.id === integrationId ? updated : i)));
    },
    []
  );

  const handleHealthCheck = useCallback(async (integrationId: string) => {
    const token = getToken();
    if (!token) throw new Error('Не авторизован');
    const res = await fetch(`${getApiBase()}/api/integrations/${integrationId}/health-check`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Ошибка проверки');
    }
    const result = (await res.json()) as {
      status?: AgentIntegration['status'];
      error?: string | null;
    };
    setIntegrations((prev) =>
      prev.map((i) =>
        i.id === integrationId
          ? { ...i, status: result.status || i.status, lastError: result.error ?? i.lastError }
          : i
      )
    );
  }, []);

  if (!agentId) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-bg px-6">
        <p className="text-text-muted">Выберите агента для управления интеграциями</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg px-6 py-8 sm:px-10 lg:px-16 xl:px-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      >
        <h1 className="heading-2 text-text dark:text-white mb-2">Интеграции</h1>
        <p className="body-large mb-8">
          Подключите каналы, CRM, платежи и автоматизацию к вашему агенту
        </p>
      </motion.div>

      {loading ? (
        <div className="flex items-center gap-2 text-text-muted">
          <div className="h-4 w-4 animate-spin rounded-full border-2 border-border-2 border-t-brand" />
          Загрузка интеграций...
        </div>
      ) : error ? (
        <div className="rounded-card border border-danger bg-danger-soft p-4 text-danger">
          {error}
        </div>
      ) : (
        <ChannelGrid
          providers={providers}
          integrations={integrations}
          agentId={agentId}
          onConnect={handleConnect}
          onDisconnect={handleDisconnect}
          onUpdate={handleUpdate}
          onHealthCheck={handleHealthCheck}
        />
      )}
    </div>
  );
}
