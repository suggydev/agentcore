'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  User,
  Save,
  CheckCircle2,
  Loader2,
  AlertCircle,
  Shield,
  Mail,
  Smartphone,
  Globe,
  Building2,
  Phone,
  Briefcase,
  Lock,
  Eye,
  EyeOff,
} from 'lucide-react';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || '';

interface ProfileData {
  name: string;
  email: string;
  companyName: string;
  phone: string;
  industry: string;
  companySize: string;
}

interface SecurityData {
  twoFactorEnabled: boolean;
  twoFactorMethod: 'email' | 'sms' | null;
}

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<'profile' | 'security'>('profile');
  const [profile, setProfile] = useState<ProfileData>({
    name: '', email: '', companyName: '', phone: '', industry: '', companySize: ''
  });
  const [security, setSecurity] = useState<SecurityData>({ twoFactorEnabled: false, twoFactorMethod: null });
  const [loading, setLoading] = useState(true);
  const [profileSaved, setProfileSaved] = useState(false);
  const [profileSaving, setProfileSaving] = useState(false);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [passwordSaved, setPasswordSaved] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [twoFactorLoading, setTwoFactorLoading] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [twoFactorStep, setTwoFactorStep] = useState<'idle' | 'sent' | 'verified'>('idle');

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) { window.location.href = '/login'; return; }
    const load = async () => {
      try {
        const meRes = await fetch(`${API_BASE}/api/auth/me`, { headers: { Authorization: `Bearer ${token}` } });
        if (meRes.ok) {
          const user = await meRes.json();
          setProfile({
            name: user.name || '',
            email: user.email || '',
            companyName: user.workspace?.settings?.companyName || '',
            phone: user.workspace?.settings?.phone || '',
            industry: user.workspace?.settings?.industry || '',
            companySize: user.workspace?.settings?.companySize || '',
          });
          setSecurity({
            twoFactorEnabled: user.twoFactorEnabled || false,
            twoFactorMethod: user.twoFactorMethod || null,
          });
        }
      } catch (err) {
        console.error('Failed to load settings:', err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const saveProfile = useCallback(async () => {
    const token = localStorage.getItem('token');
    if (!token) return;
    setProfileSaving(true);
    setProfileSaved(false);
    try {
      // Update user name
      await fetch(`${API_BASE}/api/auth/me`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ name: profile.name }),
      });

      // Update workspace settings
      const res = await fetch(`${API_BASE}/api/workspace`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          companyName: profile.companyName,
          phone: profile.phone,
          industry: profile.industry,
          companySize: profile.companySize,
        }),
      });
      if (res.ok) setProfileSaved(true);
    } catch (err) {
      console.error('[Settings] saveProfile:', err);
    } finally {
      setProfileSaving(false);
    }
  }, [profile]);

  const changePassword = async () => {
    if (!oldPassword) { setPasswordError('Введите текущий пароль'); return; }
    if (!newPassword || newPassword.length < 6) { setPasswordError('Пароль должен быть не менее 6 символов'); return; }
    if (newPassword !== confirmPassword) { setPasswordError('Пароли не совпадают'); return; }
    setPasswordSaving(true);
    setPasswordSaved(false);
    setPasswordError('');
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_BASE}/api/auth/change-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ oldPassword, newPassword }),
      });
      if (res.ok) {
        setPasswordSaved(true);
        setOldPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        const data = await res.json();
        setPasswordError(data.error || 'Не удалось сменить пароль');
      }
    } catch {
      setPasswordError('Ошибка соединения');
    } finally {
      setPasswordSaving(false);
    }
  };

  const toggleTwoFactor = async () => {
    if (security.twoFactorEnabled) {
      // Disable 2FA
      setTwoFactorLoading(true);
      try {
        const token = localStorage.getItem('token');
        await fetch(`${API_BASE}/api/auth/2fa/disable`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
        setSecurity(prev => ({ ...prev, twoFactorEnabled: false, twoFactorMethod: null }));
      } catch (err) {
        console.error('[Settings] disable 2FA:', err);
      } finally {
        setTwoFactorLoading(false);
      }
    } else {
      // Enable 2FA - send code
      setTwoFactorLoading(true);
      try {
        const token = localStorage.getItem('token');
        const res = await fetch(`${API_BASE}/api/auth/2fa/send-code`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          setTwoFactorStep('sent');
        }
      } catch (err) {
        console.error('[Settings] send 2FA code:', err);
      } finally {
        setTwoFactorLoading(false);
      }
    }
  };

  const verifyTwoFactorCode = async () => {
    if (!twoFactorCode.trim()) return;
    setTwoFactorLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_BASE}/api/auth/2fa/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ code: twoFactorCode }),
      });
      if (res.ok) {
        setSecurity(prev => ({ ...prev, twoFactorEnabled: true, twoFactorMethod: 'email' }));
        setTwoFactorStep('verified');
        setTwoFactorCode('');
      } else {
        setPasswordError('Неверный код');
      }
    } catch (err) {
      console.error('[Settings] verify 2FA:', err);
    } finally {
      setTwoFactorLoading(false);
    }
  };

  const container = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.06, delayChildren: 0.05 } },
  };
  const item = {
    hidden: { opacity: 0, y: 16 },
    show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] } },
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[80vh]" role="status">
        <Loader2 className="w-8 h-8 text-brand animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-10 max-w-5xl mx-auto">
      <motion.div variants={container} initial="hidden" animate="show" className="mb-8">
        <motion.div variants={item}>
          <p className="text-[11px] font-semibold uppercase tracking-label text-brand mb-2">Аккаунт</p>
          <h1 className="font-display font-bold text-2xl lg:text-3xl text-text tracking-tight">Настройки</h1>
          <p className="text-text-muted mt-1">Управление профилем и безопасностью</p>
        </motion.div>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-2 mb-8">
        {[
          { id: 'profile' as const, label: 'Профиль', icon: User },
          { id: 'security' as const, label: 'Безопасность', icon: Shield },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                active ? 'bg-brand text-white shadow-lg shadow-brand/20' : 'bg-surface-2 text-text-muted hover:text-text hover:bg-surface-3'
              }`}
            >
              <Icon size={16} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === 'profile' && (
        <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">
          {/* Profile Info */}
          <motion.div variants={item} className="bg-surface rounded-2xl border border-border shadow-sm p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center">
                <User size={20} className="text-brand" />
              </div>
              <div>
                <h3 className="font-semibold text-text">Личная информация</h3>
                <p className="text-xs text-text-muted">Ваши данные и компания</p>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-text mb-1.5">Имя</label>
                <input
                  type="text"
                  value={profile.name}
                  onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-surface rounded-xl border border-border text-sm text-text placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-text mb-1.5">Email</label>
                <input
                  type="email"
                  value={profile.email}
                  disabled
                  className="w-full px-3.5 py-2.5 bg-surface-2 rounded-xl border border-border text-sm text-text-muted cursor-not-allowed"
                />
                <p className="text-[10px] text-text-muted mt-1">Email изменить нельзя</p>
              </div>
              <div>
                <label className="block text-xs font-semibold text-text mb-1.5">Название компании</label>
                <div className="relative">
                  <Building2 size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
                  <input
                    type="text"
                    value={profile.companyName}
                    onChange={(e) => setProfile(prev => ({ ...prev, companyName: e.target.value }))}
                    className="w-full pl-10 pr-3.5 py-2.5 bg-surface rounded-xl border border-border text-sm text-text placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-text mb-1.5">Телефон</label>
                <div className="relative">
                  <Phone size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
                  <input
                    type="tel"
                    value={profile.phone}
                    onChange={(e) => setProfile(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full pl-10 pr-3.5 py-2.5 bg-surface rounded-xl border border-border text-sm text-text placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-text mb-1.5">Отрасль</label>
                <div className="relative">
                  <Briefcase size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
                  <input
                    type="text"
                    value={profile.industry}
                    onChange={(e) => setProfile(prev => ({ ...prev, industry: e.target.value }))}
                    className="w-full pl-10 pr-3.5 py-2.5 bg-surface rounded-xl border border-border text-sm text-text placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-text mb-1.5">Размер компании</label>
                <select
                  value={profile.companySize}
                  onChange={(e) => setProfile(prev => ({ ...prev, companySize: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-surface rounded-xl border border-border text-sm text-text focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all"
                >
                  <option value="">Выберите...</option>
                  <option value="1">1 человек</option>
                  <option value="2-10">2-10 человек</option>
                  <option value="11-50">11-50 человек</option>
                  <option value="51-200">51-200 человек</option>
                  <option value="201-1000">201-1000 человек</option>
                  <option value="1000+">1000+ человек</option>
                </select>
              </div>
            </div>

            <div className="mt-5 flex items-center gap-3">
              <button
                onClick={saveProfile}
                disabled={profileSaving}
                className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  profileSaved
                    ? 'bg-success/15 text-success border border-success/30'
                    : 'bg-brand text-white hover:bg-brand-hover shadow-lg shadow-brand/20'
                }`}
              >
                {profileSaving ? <Loader2 size={16} className="animate-spin" /> : profileSaved ? <CheckCircle2 size={16} /> : <Save size={16} />}
                {profileSaved ? 'Сохранено' : 'Сохранить'}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}

      {activeTab === 'security' && (
        <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">
          {/* Password Change */}
          <motion.div variants={item} className="bg-surface rounded-2xl border border-border shadow-sm p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center">
                <Lock size={20} className="text-brand" />
              </div>
              <div>
                <h3 className="font-semibold text-text">Смена пароля</h3>
                <p className="text-xs text-text-muted">Обновите пароль для безопасности</p>
              </div>
            </div>
            <div className="max-w-md space-y-3">
              <div>
                <label className="block text-xs font-semibold text-text mb-1.5">Текущий пароль</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={oldPassword}
                    onChange={(e) => { setOldPassword(e.target.value); setPasswordError(''); }}
                    placeholder="Введите текущий пароль"
                    className="w-full px-3.5 py-2.5 pr-10 bg-surface rounded-xl border border-border text-sm text-text placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all"
                  />
                  <button onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted">
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-text mb-1.5">Новый пароль</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => { setNewPassword(e.target.value); setPasswordError(''); }}
                  placeholder="Минимум 6 символов"
                  className="w-full px-3.5 py-2.5 bg-surface rounded-xl border border-border text-sm text-text placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-text mb-1.5">Подтвердите новый пароль</label>
                <div className="flex gap-3">
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => { setConfirmPassword(e.target.value); setPasswordError(''); }}
                    placeholder="Повторите новый пароль"
                    className="flex-1 px-3.5 py-2.5 bg-surface rounded-xl border border-border text-sm text-text placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all"
                  />
                  <button
                    onClick={changePassword}
                    disabled={passwordSaving || passwordSaved}
                    className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all flex-shrink-0 ${
                      passwordSaved
                        ? 'bg-success/15 text-success border border-success/30'
                        : 'bg-brand text-white hover:bg-brand-hover'
                    }`}
                  >
                    {passwordSaving ? <Loader2 size={16} className="animate-spin" /> : passwordSaved ? <CheckCircle2 size={16} /> : <Save size={16} />}
                    {passwordSaved ? 'Сохранено' : 'Сменить'}
                  </button>
                </div>
              </div>
              {passwordError && (
                <div className="flex items-center gap-1.5 text-sm text-danger">
                  <AlertCircle size={14} /> {passwordError}
                </div>
              )}
            </div>
          </motion.div>

          {/* 2FA */}
          <motion.div variants={item} className="bg-surface rounded-2xl border border-border shadow-sm p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center">
                <Mail size={20} className="text-brand" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-text">Двухфакторная аутентификация</h3>
                <p className="text-xs text-text-muted">Код подтверждения на email при входе</p>
              </div>
              <button
                onClick={toggleTwoFactor}
                disabled={twoFactorLoading}
                className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                  security.twoFactorEnabled
                    ? 'bg-danger/15 text-danger border border-danger/30 hover:bg-danger/25'
                    : 'bg-brand text-white hover:bg-brand-hover shadow-lg shadow-brand/20'
                }`}
              >
                {twoFactorLoading ? <Loader2 size={16} className="animate-spin" /> : null}
                {security.twoFactorEnabled ? 'Отключить' : 'Включить'}
              </button>
            </div>

            {twoFactorStep === 'sent' && !security.twoFactorEnabled && (
              <div className="bg-brand/5 border border-brand/20 rounded-xl p-4 mt-4">
                <p className="text-sm text-text mb-3">Код подтверждения отправлен на ваш email. Введите его ниже:</p>
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={twoFactorCode}
                    onChange={(e) => setTwoFactorCode(e.target.value)}
                    placeholder="123456"
                    className="flex-1 px-3.5 py-2.5 bg-surface rounded-xl border border-border text-sm text-text placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all text-center tracking-widest"
                    maxLength={6}
                  />
                  <button
                    onClick={verifyTwoFactorCode}
                    disabled={twoFactorLoading || twoFactorCode.length !== 6}
                    className="px-5 py-2.5 rounded-xl bg-brand text-white text-sm font-semibold hover:bg-brand-hover transition-all disabled:opacity-50"
                  >
                    {twoFactorLoading ? <Loader2 size={16} className="animate-spin" /> : 'Подтвердить'}
                  </button>
                </div>
              </div>
            )}

            {security.twoFactorEnabled && (
              <div className="flex items-center gap-2 mt-4 text-sm text-success">
                <CheckCircle2 size={16} />
                <span>2FA включена через email</span>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
