'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Logo from './Logo';
import {
 Bot,
 Settings,
 LogOut,
 Users,
} from 'lucide-react';

const navItems = [
  { label: 'Агенты', icon: Bot, href: '/agents' },
  { label: 'Команда', icon: Users, href: '/team' },
  { label: 'Настройки', icon: Settings, href: '/settings' },
];

export interface NewSidebarProps {
 onOpenCommandPalette?: () => void;
}

export default function NewSidebar({ onOpenCommandPalette }: NewSidebarProps) {
 const pathname = usePathname();
 const [userMenuOpen, setUserMenuOpen] = useState(false);
 const userMenuRef = useRef<HTMLDivElement>(null);
 const [balance, setBalance] = useState(0);

  useEffect(() => {
   const API_BASE = process.env.NEXT_PUBLIC_API_URL || '';
   const token = localStorage.getItem('token');
   if (!token) return;
   fetch(`${API_BASE}/api/billing/suggy-balance`, {
    headers: { Authorization: `Bearer ${token}` },
   })
   .then((res) => {
     if (res.status === 401) {
       localStorage.removeItem('token');
       window.location.href = '/login';
       return Promise.reject(new Error('Unauthorized'));
     }
     return res.ok ? res.json() : Promise.reject(res);
   })
   .then((data) => setBalance(data.balance ?? 0))
   .catch(err => { console.error('[NewSidebar] Failed to load balance:', err); });
  }, []);

 useEffect(() => {
  if (userMenuOpen) {
   const handler = (e: MouseEvent) => {
    if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
     setUserMenuOpen(false);
    }
   };
   document.addEventListener('mousedown', handler);
   return () => document.removeEventListener('mousedown', handler);
  }
 }, [userMenuOpen]);

 const isActive = (href: string) => {
  if (href === '/agents') return pathname === '/agents' || pathname.startsWith('/agents/');
  return pathname.startsWith(href);
 };

  const [displayName, setDisplayName] = useState<string | null>(null);
  const [displayEmail, setDisplayEmail] = useState<string | null>(null);

  useEffect(() => {
   const storedName = localStorage.getItem('userName');
   const storedEmail = localStorage.getItem('userEmail');
   const userStr = localStorage.getItem('user');
   let parsedUser: { name?: string; email?: string } | null = null;
   if (userStr) {
    try { parsedUser = JSON.parse(userStr); } catch { /* ignore */ }
   }
   setDisplayName(storedName || parsedUser?.name || null);
   setDisplayEmail(storedEmail || parsedUser?.email || null);
  }, []);

 return (
  <div className="flex flex-col h-full bg-surface/80 backdrop-blur-xl border-r border-border">
  <div className="px-5 pt-6 pb-5">
  <Link href="/agents" className="inline-flex" aria-label="На главную">
  <Logo size={24} />
  </Link>
  </div>

  <nav className="flex-1 px-3 py-1 space-y-0.5 overflow-y-auto" role="navigation" aria-label="Основная навигация">
  {navItems.map((item) => {
  const active = isActive(item.href);
  const Icon = item.icon;
  return (
  <Link
  key={item.href}
  href={item.href}
  className={`relative flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 group ${
  active
  ? 'bg-accent-soft text-brand'
  : 'text-text-muted hover:text-text hover:bg-surface-2'
  }`}
  aria-current={active ? 'page' : undefined}
  >
  {active && (
  <motion.div
  layoutId="active-border"
  className="absolute left-0 top-1.5 bottom-1.5 w-0.5 rounded-full bg-brand"
  transition={{ type: 'spring', damping: 26, stiffness: 300 }}
  />
  )}
  <Icon
  size={18}
  className={`transition-colors duration-200 ${
  active ? 'text-brand' : 'text-text-muted group-hover:text-text-muted'
  }`}
  />
  <span>{item.label}</span>
  </Link>
  );
  })}
  </nav>

   <div className="mx-5 mb-2">
   <div className="h-px bg-border/40" />
   </div>

  <div className="px-3 py-2 space-y-2">
  {/* Balance Card */}
  <div className="rounded-card bg-gradient-to-br from-brand/10 to-brand/5 border border-brand/20 p-3">
  <div className="flex items-center justify-between mb-1">
  <span className="text-[10px] font-semibold uppercase tracking-wider text-brand">AI Баланс</span>
  <span className="text-[10px] text-brand/70">₽</span>
  </div>
  <div className="font-mono font-bold text-xl text-text mb-2">{balance.toFixed(2).replace('.', ',')}</div>
  <Link
    href="/settings/upgrade"
    className="flex items-center justify-center gap-1.5 w-full px-3 py-2 rounded-lg bg-brand/15 hover:bg-brand/25 text-brand text-xs font-semibold transition-colors text-center"
  >
    Пополнить
  </Link>
  </div>

  {/* Profile */}
  <Link href="/settings" className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-surface-2 transition-colors group">
  <div className="w-8 h-8 rounded-full bg-brand text-white flex items-center justify-center text-xs font-semibold flex-shrink-0 group-hover:scale-105 transition-transform">
  {displayName?.charAt(0).toUpperCase() || '?'}
  </div>
  <div className="flex-1 min-w-0">
  <p className="text-sm font-medium text-text truncate leading-tight">{displayName || '\u2014'}</p>
  <p className="text-[11px] text-text-muted truncate leading-tight">{displayEmail || '\u2014'}</p>
  </div>
  <Settings size={14} className="text-text-muted opacity-0 group-hover:opacity-100 transition-opacity" />
  </Link>

  <button
  type="button"
  onClick={async () => {
  document.cookie = 'token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; SameSite=Lax;';
  try {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
  } catch {}
  localStorage.clear();
  window.location.href = '/login';
  }}
  className="flex items-center gap-2.5 px-3 py-2 text-sm text-danger hover:bg-danger-soft transition-colors duration-150 w-full text-left rounded-lg"
  >
  <LogOut size={15} />
  Выйти
  </button>
  </div>
  </div>
  );
}
