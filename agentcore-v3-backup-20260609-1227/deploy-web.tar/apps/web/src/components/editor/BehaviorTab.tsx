'use client';

import { useState } from 'react';
import { Brain, LayoutList } from 'lucide-react';
import PromptTab from './PromptTab';
import BrainMapTab from './BrainMapTab';
import type { AgentData, ModelOption } from './types';

interface BehaviorTabProps {
  agent: AgentData;
  onUpdate: (updates: Partial<AgentData>) => Promise<void>;
  models: ModelOption[];
}

export default function BehaviorTab({ agent, onUpdate, models }: BehaviorTabProps) {
  const [mode, setMode] = useState<'map' | 'blocks'>('map');

  return (
    <div className="flex flex-col h-full">
      {/* Toggle */}
      <div className="flex items-center gap-1 px-5 pt-4 pb-2">
        <button
          onClick={() => setMode('map')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            mode === 'map'
              ? 'bg-brand text-white shadow-sm'
              : 'bg-surface-2 text-text-muted hover:text-text'
          }`}
        >
          <Brain size={14} />
          Brain Map
        </button>
        <button
          onClick={() => setMode('blocks')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            mode === 'blocks'
              ? 'bg-brand text-white shadow-sm'
              : 'bg-surface-2 text-text-muted hover:text-text'
          }`}
        >
          <LayoutList size={14} />
          Блоки
        </button>
      </div>

      <div className="flex-1 min-h-0 overflow-hidden">
        {mode === 'map' ? (
          <BrainMapTab
            agent={agent}
            container={{
              hidden: { opacity: 0 },
              show: { opacity: 1, transition: { staggerChildren: 0.06, delayChildren: 0.05 } },
            }}
            item={{
              hidden: { opacity: 0, y: 16 },
              show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] } },
            }}
            onUpdate={(a) => onUpdate(a as Partial<AgentData>)}
          />
        ) : (
          <PromptTab agent={agent} onUpdate={onUpdate} models={models} />
        )}
      </div>
    </div>
  );
}
