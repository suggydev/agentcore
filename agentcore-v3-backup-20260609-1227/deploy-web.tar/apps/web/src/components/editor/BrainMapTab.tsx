'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, MessageCircle, Zap, HelpCircle, Rocket, AlertTriangle, Blocks, Database, Wand2, Users, Plus, Trash2, Link2, Unlink, Move, Sparkles, CheckCircle2, X, GripVertical, ChevronRight } from 'lucide-react';

const NODE_TYPES = [
  { type: 'greeting', label: 'Приветствие', icon: MessageCircle, color: '#6E56CF', bg: 'bg-[#6E56CF]/15' },
  { type: 'qualification', label: 'Квалификация', icon: Zap, color: '#6E56CF', bg: 'bg-[#6E56CF]/15' },
  { type: 'faq', label: 'FAQ', icon: HelpCircle, color: '#3A8F7A', bg: 'bg-[#3A8F7A]/15' },
  { type: 'leadCapture', label: 'Сбор лидов', icon: Rocket, color: '#6E56CF', bg: 'bg-[#6E56CF]/15' },
  { type: 'escalation', label: 'Эскалация', icon: AlertTriangle, color: '#D97706', bg: 'bg-[#D97706]/15' },
  { type: 'integration', label: 'Интеграция', icon: Blocks, color: '#6E56CF', bg: 'bg-[#6E56CF]/15' },
  { type: 'memory', label: 'Память', icon: Database, color: '#3A8F7A', bg: 'bg-[#3A8F7A]/15' },
  { type: 'handoff', label: 'Передача', icon: Users, color: '#D97706', bg: 'bg-[#D97706]/15' },
  { type: 'custom', label: 'Пользовательский', icon: Wand2, color: '#7C7F86', bg: 'bg-[#7C7F86]/15' },
];

interface BrainNode {
  id: string;
  type: string;
  label?: string;
  x: number;
  y: number;
  active: boolean;
  parentId?: string | null;
}

interface BrainMapTabProps {
  agent: any;
  container: any;
  item: any;
  onUpdate: (agent: any) => void;
}

export default function BrainMapTab({ agent, container, item, onUpdate }: BrainMapTabProps) {
  const [nodes, setNodes] = useState<BrainNode[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [linkingMode, setLinkingMode] = useState(false);
  const [linkingSource, setLinkingSource] = useState<string | null>(null);
  const [showAddPanel, setShowAddPanel] = useState(false);
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const getNodeMeta = (type: string) => NODE_TYPES.find(n => n.type === type) || NODE_TYPES[NODE_TYPES.length - 1];

  // Initialize nodes from agent settings or defaults
  useEffect(() => {
    if (!agent?.settings?.brainMap?.nodes) {
      const defaults = [
        { id: 'greeting', type: 'greeting', x: 300, y: 200, active: true },
        { id: 'qualification', type: 'qualification', x: 500, y: 150, active: true, parentId: 'greeting' },
        { id: 'faq', type: 'faq', x: 500, y: 250, active: true, parentId: 'greeting' },
        { id: 'escalation', type: 'escalation', x: 700, y: 100, active: true, parentId: 'qualification' },
        { id: 'leadCapture', type: 'leadCapture', x: 700, y: 200, active: false, parentId: 'qualification' },
        { id: 'memory', type: 'memory', x: 500, y: 350, active: true, parentId: 'greeting' },
      ];
      setNodes(defaults);
    } else {
      setNodes(agent.settings.brainMap.nodes);
    }
  }, [agent]);

  // Save nodes to agent
  const saveNodes = useCallback((newNodes: BrainNode[]) => {
    setNodes(newNodes);
    if (onUpdate) {
      onUpdate({
        ...agent,
        settings: {
          ...agent.settings,
          brainMap: { nodes: newNodes }
        }
      });
    }
  }, [agent, onUpdate]);

  const addNode = (type: string) => {
    const meta = getNodeMeta(type);
    const newNode: BrainNode = {
      id: `${type}-${Date.now()}`,
      type,
      label: meta.label,
      x: 300 + Math.random() * 200,
      y: 200 + Math.random() * 100,
      active: true,
    };
    saveNodes([...nodes, newNode]);
    setShowAddPanel(false);
  };

  const removeNode = (id: string) => {
    const filtered = nodes.filter(n => n.id !== id).map(n => n.parentId === id ? { ...n, parentId: null } : n);
    saveNodes(filtered);
    setSelectedId(null);
  };

  const toggleActive = (id: string) => {
    saveNodes(nodes.map(n => n.id === id ? { ...n, active: !n.active } : n));
  };

  const startLinking = (id: string) => {
    if (linkingMode && linkingSource === id) {
      setLinkingMode(false);
      setLinkingSource(null);
    } else if (linkingMode && linkingSource) {
      // Complete link
      saveNodes(nodes.map(n => n.id === id ? { ...n, parentId: linkingSource } : n));
      setLinkingMode(false);
      setLinkingSource(null);
    } else {
      setLinkingMode(true);
      setLinkingSource(id);
    }
  };

  const handleMouseDown = (e: React.MouseEvent, nodeId: string) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;
    setDraggingId(nodeId);
    setDragOffset({
      x: e.clientX - rect.left - node.x,
      y: e.clientY - rect.top - node.y
    });
    setSelectedId(nodeId);
  };

  const handleTouchStart = (e: React.TouchEvent, nodeId: string) => {
    if (!svgRef.current || e.touches.length !== 1) return;
    const rect = svgRef.current.getBoundingClientRect();
    const touch = e.touches[0];
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;
    setDraggingId(nodeId);
    setDragOffset({
      x: touch.clientX - rect.left - node.x,
      y: touch.clientY - rect.top - node.y
    });
    setSelectedId(nodeId);
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!draggingId || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left - dragOffset.x;
    const y = e.clientY - rect.top - dragOffset.y;
    setNodes(prev => prev.map(n => n.id === draggingId ? { ...n, x: Math.max(40, Math.min(760, x)), y: Math.max(40, Math.min(410, y)) } : n));
  }, [draggingId, dragOffset]);

  const handleTouchMove = useCallback((e: TouchEvent) => {
    if (!draggingId || !svgRef.current || e.touches.length !== 1) return;
    e.preventDefault();
    const rect = svgRef.current.getBoundingClientRect();
    const touch = e.touches[0];
    const x = touch.clientX - rect.left - dragOffset.x;
    const y = touch.clientY - rect.top - dragOffset.y;
    setNodes(prev => prev.map(n => n.id === draggingId ? { ...n, x: Math.max(40, Math.min(760, x)), y: Math.max(40, Math.min(410, y)) } : n));
  }, [draggingId, dragOffset]);

  const handleMouseUp = useCallback(() => {
    if (draggingId) {
      setDraggingId(null);
      saveNodes(nodes);
    }
  }, [draggingId, nodes, saveNodes]);

  const handleTouchEnd = useCallback(() => {
    if (draggingId) {
      setDraggingId(null);
      saveNodes(nodes);
    }
  }, [draggingId, nodes, saveNodes]);

  useEffect(() => {
    if (draggingId) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('touchmove', handleTouchMove, { passive: false });
      window.addEventListener('touchend', handleTouchEnd);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
        window.removeEventListener('touchmove', handleTouchMove);
        window.removeEventListener('touchend', handleTouchEnd);
      };
    }
  }, [draggingId, handleMouseMove, handleMouseUp, handleTouchMove, handleTouchEnd]);

  const connections = nodes.filter(n => n.parentId).map(n => {
    const parent = nodes.find(p => p.id === n.parentId);
    return parent ? { from: parent, to: n } : null;
  }).filter(Boolean) as { from: BrainNode; to: BrainNode }[];

  const selectedNode = nodes.find(n => n.id === selectedId);

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4 px-5 pt-5">
        <div className="w-10 h-10 rounded-xl bg-[var(--accent-soft)] flex items-center justify-center ring-1 ring-[var(--border)]/60">
          <Brain className="w-5 h-5 text-[var(--brand)]" />
        </div>
        <div>
          <h3 className="font-semibold text-[var(--text)]">Brain Map</h3>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">Интерактивная логика работы агента</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={() => setLinkingMode(!linkingMode)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${linkingMode ? 'bg-brand text-white' : 'bg-surface-2 text-text hover:bg-surface-3'}`}
          >
            {linkingMode ? 'Выберите цель' : <><Link2 size={12} className="inline mr-1" /> Связать</>}
          </button>
          <button
            onClick={() => setShowAddPanel(!showAddPanel)}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-brand text-white hover:bg-brand-hover transition-colors"
          >
            <Plus size={12} className="inline mr-1" /> Добавить
          </button>
        </div>
      </div>

      <div className="flex-1 flex min-h-0 px-5 pb-5 gap-4">
        {/* Canvas */}
        <div className="flex-1 relative bg-[var(--surface-2)] rounded-2xl border border-[var(--border)] overflow-hidden" ref={containerRef}>
          <svg ref={svgRef} viewBox="0 0 800 450" className="w-full h-full cursor-grab active:cursor-grabbing touch-none">
            {/* Grid pattern */}
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <circle cx="20" cy="20" r="1" fill="var(--text-muted)" opacity="0.15" />
              </pattern>
            </defs>
            <rect width="800" height="450" fill="url(#grid)" />

            {/* Connections */}
            {connections.map((conn, i) => (
              <g key={`conn-${i}`}>
                <path
                  d={`M ${conn.from.x} ${conn.from.y} Q ${(conn.from.x + conn.to.x) / 2} ${(conn.from.y + conn.to.y) / 2 - 20} ${conn.to.x} ${conn.to.y}`}
                  fill="none"
                  stroke={conn.to.active ? 'var(--brand)' : 'var(--text-muted)'}
                  strokeWidth={conn.to.active ? 2 : 1}
                  opacity={conn.to.active ? 0.6 : 0.2}
                  strokeDasharray={conn.to.active ? 'none' : '4 4'}
                />
              </g>
            ))}

            {/* Pending link line */}
            {linkingMode && linkingSource && (() => {
              const source = nodes.find(n => n.id === linkingSource);
              if (!source) return null;
              return (
                <line
                  x1={source.x}
                  y1={source.y}
                  x2={source.x + 100}
                  y2={source.y}
                  stroke="var(--brand)"
                  strokeWidth={2}
                  strokeDasharray="8 4"
                  opacity={0.6}
                >
                  <animate attributeName="x2" values={`${source.x + 50};${source.x + 150};${source.x + 50}`} dur="2s" repeatCount="indefinite" />
                  <animate attributeName="y2" values={`${source.y - 30};${source.y + 30};${source.y - 30}`} dur="2s" repeatCount="indefinite" />
                </line>
              );
            })()}

            {/* Nodes */}
            {nodes.map(node => {
              const meta = getNodeMeta(node.type);
              const isSelected = selectedId === node.id;
              const isLinking = linkingMode && linkingSource === node.id;
              const isTarget = linkingMode && linkingSource && linkingSource !== node.id;
              return (
                <g
                  key={node.id}
                  transform={`translate(${node.x}, ${node.y})`}
                  onMouseDown={(e) => handleMouseDown(e, node.id)}
                  onTouchStart={(e) => handleTouchStart(e, node.id)}
                  className="cursor-grab active:cursor-grabbing"
                  style={{ cursor: isTarget ? 'crosshair' : 'grab' }}
                >
                  {/* Glow effect for selected */}
                  {isSelected && (
                    <circle r="36" fill="var(--brand)" opacity="0.1">
                      <animate attributeName="r" values="36;40;36" dur="2s" repeatCount="indefinite" />
                    </circle>
                  )}
                  {isLinking && (
                    <circle r="38" fill="none" stroke="var(--brand)" strokeWidth={2} strokeDasharray="4 4">
                      <animate attributeName="r" values="38;42;38" dur="1s" repeatCount="indefinite" />
                    </circle>
                  )}
                  {/* Node body */}
                  <circle
                    r="32"
                    fill={node.active ? 'var(--surface)' : 'var(--surface-2)'}
                    stroke={isSelected ? 'var(--brand)' : node.active ? meta.color : 'var(--text-muted)'}
                    strokeWidth={isSelected ? 3 : 2}
                    opacity={node.active ? 1 : 0.5}
                    className={isTarget ? 'animate-pulse' : ''}
                  />
                  {/* Icon placeholder */}
                  <foreignObject x="-10" y="-18" width="20" height="20">
                    <div className="flex items-center justify-center w-full h-full">
                      <meta.icon size={14} color={node.active ? meta.color : '#7C7F86'} />
                    </div>
                  </foreignObject>
                  {/* Label */}
                  <text
                    y="14"
                    textAnchor="middle"
                    fill={node.active ? 'var(--text)' : 'var(--text-muted)'}
                    fontSize="10"
                    fontWeight="500"
                  >
                    {meta.label}
                  </text>
                  {/* Active indicator */}
                  {node.active && (
                    <circle cx="24" cy="-24" r="5" fill="#3A8F7A" />
                  )}
                  {/* Click target for linking */}
                  {isTarget && (
                    <circle r="40" fill="transparent" onClick={() => startLinking(node.id)} style={{ cursor: 'crosshair' }} />
                  )}
                </g>
              );
            })}
          </svg>

          {/* Legend / Instructions */}
          <div className="absolute bottom-3 left-3 bg-surface/90 backdrop-blur-sm rounded-xl px-3 py-2 border border-border text-[10px] text-text-muted space-y-1">
            <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-[#6E56CF]" /> Основная логика</div>
            <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-[#3A8F7A]" /> Данные/Память</div>
            <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-[#D97706]" /> Эскалация</div>
            <div className="flex items-center gap-1.5"><GripVertical size={10} /> Перетаскивайте узлы</div>
            <div className="flex items-center gap-1.5"><Link2 size={10} /> Нажмите «Связать» для соединения</div>
          </div>
        </div>

        {/* Sidebar - Node Details */}
        <AnimatePresence>
          {selectedNode && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 280, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="bg-surface rounded-2xl border border-border overflow-hidden flex flex-col"
            >
              <div className="p-4 border-b border-border">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${getNodeMeta(selectedNode.type).bg}`}>
                      {(() => {
                        const MetaIcon = getNodeMeta(selectedNode.type).icon;
                        return <MetaIcon size={14} color={getNodeMeta(selectedNode.type).color} />;
                      })()}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-text">{getNodeMeta(selectedNode.type).label}</p>
                      <p className="text-[10px] text-text-muted">ID: {selectedNode.id.slice(0, 8)}</p>
                    </div>
                  </div>
                  <button onClick={() => setSelectedId(null)} className="text-text-muted hover:text-text">
                    <X size={14} />
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleActive(selectedNode.id)}
                    className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-1.5 ${
                      selectedNode.active ? 'bg-success/15 text-success' : 'bg-surface-3 text-text-muted'
                    }`}
                  >
                    {selectedNode.active ? <><CheckCircle2 size={12} /> Активно</> : <><X size={12} /> Отключено</>}
                  </button>
                  <button
                    onClick={() => startLinking(selectedNode.id)}
                    className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                      linkingMode && linkingSource === selectedNode.id ? 'bg-brand text-white' : 'bg-surface-3 text-text hover:bg-surface-2'
                    }`}
                  >
                    <Link2 size={12} />
                  </button>
                  <button
                    onClick={() => removeNode(selectedNode.id)}
                    className="px-3 py-2 rounded-lg text-xs font-medium bg-danger/15 text-danger hover:bg-danger/25 transition-colors"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>

              <div className="p-4 flex-1 overflow-y-auto">
                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] font-medium text-text-muted uppercase tracking-wider mb-1.5 block">Позиция</label>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="px-3 py-2 bg-surface-2 rounded-lg text-xs text-text">X: {Math.round(selectedNode.x)}</div>
                      <div className="px-3 py-2 bg-surface-2 rounded-lg text-xs text-text">Y: {Math.round(selectedNode.y)}</div>
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-text-muted uppercase tracking-wider mb-1.5 block">Связи</label>
                    <div className="space-y-1.5">
                      {connections.filter(c => c.from.id === selectedNode.id || c.to.id === selectedNode.id).map((conn, i) => (
                        <div key={i} className="flex items-center gap-2 px-3 py-2 bg-surface-2 rounded-lg text-xs text-text">
                          <span className="text-text-muted">{conn.from.id === selectedNode.id ? '→' : '←'}</span>
                          <span>{conn.from.id === selectedNode.id ? getNodeMeta(conn.to.type).label : getNodeMeta(conn.from.type).label}</span>
                        </div>
                      ))}
                      {connections.filter(c => c.from.id === selectedNode.id || c.to.id === selectedNode.id).length === 0 && (
                        <p className="text-[11px] text-text-muted italic">Нет связей</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-text-muted uppercase tracking-wider mb-1.5 block">Дочерние узлы</label>
                    <div className="space-y-1.5">
                      {nodes.filter(n => n.parentId === selectedNode.id).map(child => (
                        <div key={child.id} className="flex items-center gap-2 px-3 py-2 bg-surface-2 rounded-lg text-xs text-text">
                          <ChevronRight size={10} className="text-brand" />
                          <span>{getNodeMeta(child.type).label}</span>
                          <span className={`ml-auto w-1.5 h-1.5 rounded-full ${child.active ? 'bg-success' : 'bg-text-muted'}`} />
                        </div>
                      ))}
                      {nodes.filter(n => n.parentId === selectedNode.id).length === 0 && (
                        <p className="text-[11px] text-text-muted italic">Нет дочерних узлов</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Add Node Panel */}
      <AnimatePresence>
        {showAddPanel && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-border bg-surface-2 px-5 py-4"
          >
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={14} className="text-brand" />
              <span className="text-sm font-medium text-text">Добавить логический блок</span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {NODE_TYPES.map(nodeType => (
                <button
                  key={nodeType.type}
                  onClick={() => addNode(nodeType.type)}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-surface border border-border hover:border-brand/50 hover:bg-surface-3 transition-all group"
                >
                  <div className={`w-8 h-8 rounded-lg ${nodeType.bg} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <nodeType.icon size={14} color={nodeType.color} />
                  </div>
                  <span className="text-[10px] font-medium text-text">{nodeType.label}</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
