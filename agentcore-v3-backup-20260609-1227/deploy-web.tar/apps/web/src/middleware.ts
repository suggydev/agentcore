import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Токен хранится в localStorage, cookie-проверка невозможна.
  // Авторизация проверяется на клиенте (useEffect + localStorage).
  // Middleware используется только для общих заголовков и редиректов.

  if (pathname === '/login') {
    return NextResponse.next();
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/dashboard/:path*', '/agents/:path*', '/chat/:path*', '/onboarding/:path*', '/login', '/knowledge/:path*', '/settings/:path*'],
};
